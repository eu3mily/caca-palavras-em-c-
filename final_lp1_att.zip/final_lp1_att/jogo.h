#ifndef JOGO_H
#define JOGO_H

#define MAX 20
#define MAX_PALAVRAS 10
#define MAX_LEN MAX

#define COR_RESET "\033[0m"
#define COR_VERDE "\033[32m"
#define COR_VERMELHA "\033[31m"
#define COR_AMARELA "\033[33m"
#define COR_AZUL "\033[34m"
#define COR_MAGENTA "\033[35m"
#define TEXTO_NEGRITO "\033[1m"

/* enum - criando um grupo de nomes que representam valores numericos inteiros, nesse caso para modos de jogo
ex: facil 1 medio 2 dificil 3 */
typedef enum {
    FACIL = 1, MEDIO, DIFICIL 
} Dificuldade;
// agora para as direcoes
typedef enum {
    HORIZONTAL,
    VERTICAL,
    DIAGONAL
} Direcao;
// agora para salvar no replay
typedef enum {
    ACERTO,
    ERRO,
    REPETIDA
} ResultadoJogada;

// estrutura q vai representar uma palavra no jogo
typedef struct {
    char texto[MAX_LEN]; // texto da palavra q vai ser add no jogo de acordo com os requisitos definidos acima (ex: "flamengo")
    int encontrada; // bool p verif se foi encontrada: 0 - nao foi, 1 - foi 
    int linha; // linha inicial 
    int coluna; // coluna inicial
    Direcao direcao; //guarda a direção da palavra
    int dicaUsada; //0 = não usada, 1 = já usadado
} Palavra;



void carregarPalavras(Palavra palavras[], int *qtd); // carrega as palavras dentro do arquivo
void fileiniciarreplay(Dificuldade modo, int tamanho, Palavra palavras[]);
void mostrarMatriz(char matriz[MAX][MAX], int tamanho); // so pra organizar os indices
void preencherMatriz(char matriz[MAX][MAX], int tamanho); // preencher c letras aleatorias
void inserirPalavrasNaMatriz(char matriz[MAX][MAX], int ocupado[MAX][MAX], Palavra palavras[], int qtd, int tamanho);
int buscarPalavra(Palavra palavras[], int qtd, char busca[MAX_LEN], int linhaDigitada);
/*void mostrarCoordenadas(Palavra palavras[], int qtd); */
Dificuldade selecionarDificuldade(int *tamanhoMatriz, int *qtdPalavras);
void salvarResultado(Palavra palavras[], int qtd);
void fileexecutareplay();
void substituirPorAsteriscos(char matriz[MAX][MAX], Palavra *p);
void darDica(Palavra palavras[], int qtd);
void filejogadasreplay(char tentativa[], ResultadoJogada resultado);
void salvarScoreAcumulado(Dificuldade modo);
const char* filestatusjogada(ResultadoJogada r);


#endif