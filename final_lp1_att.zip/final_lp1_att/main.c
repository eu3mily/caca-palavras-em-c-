// * add um replay e um acumulativo em resultado, tipo todas as jogadas ja feitas serem salvas
// lembrar da entrada do usuario #V3, p ver proximidade
// substituir as palavras ja achadas por ***
// criatividade!!!! - implementar dica

#include <stdio.h>
#include <stdlib.h> //p funcoes de aleatoriedade
#include <string.h>
#include <ctype.h> //p mexer nas char maiusculas e minusculas, usa "toupper" "tolower" etc
#include <time.h> //p gerar seed aleatoriedade
#include "jogo.h"

int main() {
	srand(time(NULL)); // inicializa a aleatoriedade

	int qtdPalavrasPermitidas;
	int tamanhoMatriz;

	Dificuldade modo = selecionarDificuldade(&tamanhoMatriz, &qtdPalavrasPermitidas);
	char matriz[MAX][MAX]; // a matriz
	int ocupado[MAX][MAX] = {0}; 
	Palavra palavras[MAX_PALAVRAS]; // palavras do jogo
	int qtdPalavras = 0; // nC:mero de palavras
	char tentativa[MAX_LEN]; // palavra a ser testada pelo jogador
	int acertos = 0; // contador de palavras encontradas

	preencherMatriz(matriz, tamanhoMatriz);  // preenche a matriz com letras aleatC3rias
	carregarPalavras(palavras, &qtdPalavras); // carrega as palavras do arquivo
	fileiniciarreplay(modo, tamanhoMatriz, palavras); // inicializa o replay

	if (qtdPalavras > qtdPalavrasPermitidas)
		qtdPalavras = qtdPalavrasPermitidas; // garante o numero maximo de palavras permitidas

	inserirPalavrasNaMatriz(matriz, ocupado, palavras, qtdPalavras, tamanhoMatriz); // insere as palavras na matriz
	/*mostrarCoordenadas(palavras, qtdPalavras); */  // mostra onde as palavras estC#o escondidas

	printf(TEXTO_NEGRITO "\n\n==-== JOGO DE CACA-PALAVRAS - TRABALHO FINAL - (MODO %s) ==-==\n\n" COR_RESET,
	       modo == FACIL ? "FACIL" : (modo == MEDIO ? "MEDIO" : "DIFICIL"));
	mostrarMatriz(matriz, tamanhoMatriz); // mostra o tabuleiro

	while (acertos < qtdPalavras) {
		printf("\n ----> digite a palavra e a linha inicial onde ela esta (ex: 'BAHIA 3'): ");
		int linhaDigitada;
		printf("\n ----> para sair, digite 'SAIR 0': \n ----> ouu, digite 'DICA 0' para receber uma dica (max 2 dicas por jogo!)\n");
		scanf("%s %d", tentativa, &linhaDigitada);

		for (int i = 0; tentativa[i]; i++)
			tentativa[i] = toupper(tentativa[i]);

		if (strcmp(tentativa, "SAIR") == 0)
			break;

		if (strcmp(tentativa, "DICA") == 0) {
			static int dicasUsadas = 0;
			if (dicasUsadas >= 2) {
				printf("\nvoce ja usou todas as suas dicas! tente sozin\n");
			} else {
				darDica(palavras, qtdPalavras);
				dicasUsadas++;
			}
			continue;
		}

		int indice = buscarPalavra(palavras, qtdPalavras, tentativa, linhaDigitada);
		ResultadoJogada status;

		if (indice >= 0) {
			substituirPorAsteriscos(matriz, &palavras[indice]);
			mostrarMatriz(matriz, tamanhoMatriz);
			acertos++;
			status = ACERTO;
		}
		else if (indice == -2) {
			status = REPETIDA;
		}
		else {
			printf(COR_VERMELHA "\npalavra nao encontrada! tente novamente.\n" COR_RESET);
			status = ERRO;
		}

		filejogadasreplay(tentativa, status); 
	}

	if (acertos == qtdPalavras) {
        // Se venceu, salva e exibe a pontuação acumulada
        salvarScoreAcumulado(modo);
    } else {
        printf(COR_AMARELA "\nPartida finalizada sem completar o caça-palavras. Score nao acumulado.\n" COR_RESET);
    }

	salvarResultado(palavras, qtdPalavras);  // salva o resultado final
	printf(COR_MAGENTA"\njogo encerrado!! o seu resultado ta salvo em 'resultado.txt', pode conferir.\n"COR_RESET);
	char op;
	printf(COR_AZUL"\ndeseja ver o resumo da partida? (s/n): "COR_RESET);
	scanf(" %c", &op);

	if (tolower(op) == 's') {
		fileexecutareplay();
	}

	return 0;
}



