#include <stdio.h>
#include <stdlib.h> //p funcoes de aleatoriedade
#include <string.h>
#include <ctype.h> //p mexer nas char maiusculas e minusculas, usa "toupper" "tolower" etc
#include <time.h> //p gerar seed aleatoriedade
#include "jogo.h"

// variavel para saber o tamanho atual da matriz (usada no limitador de palavras e como parametro para dificuldade)
int tamanhoMatriz;
static int partidas_jogadas = 0;

// função para escolher o modo de jogo
Dificuldade selecionarDificuldade(int *tamanhoMatrizParam, int *qtdPalavras) {
    int opcao;
    int leitura_sucesso; // Variável para capturar o retorno do scanf

    do {
        printf("SEJA BEM VINDO AO NOSSO JOGO DE CACA-PALAVRAS :)\n");
        printf("\nprimeiramente, selecione (entre 1 a 3) o modo de jogo que deseja:\n\n");
        printf("1: facil (10x10, 3 palavras para voce encontrar)\n");
        printf("2: medio (15x15, 5 palavras para voce encontrar)\n");
        printf("3: dificil (20x20, 7 palavras para voce encontrar)\n");
        printf("\nsua escolha: ");
        
        // Tenta ler um inteiro. leitura_sucesso será 1 se ler um inteiro, 0 se falhar.
        leitura_sucesso = scanf("%d", &opcao);
        
        // 1. Caso a leitura do inteiro FALHE (o usuário digitou uma letra ou símbolo)
        if (leitura_sucesso != 1) {
            printf("\nERRO DE ENTRADA: Por favor, digite APENAS números inteiros entre 1 e 3.\n");
            opcao = 0; // Define 'opcao' como inválida para garantir que o loop continue.

            // Limpa o buffer de entrada: remove todos os caracteres inválidos deixados pelo scanf.
            while (getchar() != '\n'); 

        // 2. Caso a leitura tenha sucesso, mas o número esteja fora do intervalo [1, 3]
        } else if (opcao < 1 || opcao > 3) {
            printf("\nMODO INVÁLIDO: Escolha apenas números entre 1 e 3... \n");
            printf("Voce sera redirecionado para o menu inicial do jogo! \n\n\n\n");
        }
        
    } while (opcao < 1 || opcao > 3); // O loop continua se a opção for inválida (0, -1, 4, etc.)
    
    // Configuração final da matriz e retorno da dificuldade
    switch (opcao) {
        case 1:
            *tamanhoMatrizParam = 10;
            *qtdPalavras = 3;
            tamanhoMatriz = 10;
            return FACIL;
        case 2:
            *tamanhoMatrizParam = 15;
            *qtdPalavras = 5;
            tamanhoMatriz = 15;
            return MEDIO;
        case 3:
        default:
            *tamanhoMatrizParam = 20;
            *qtdPalavras = 7;
            tamanhoMatriz = 20;
            return DIFICIL;
    }
}

void preencherMatriz(char matriz[MAX][MAX], int tamanho) {  // preenche a matriz com letras aleatorias dentro do tamanho definido supracitadamente
    for (int i = 0; i < tamanho; i++) // corre linhas de acordo c o tamanho
        for (int j = 0; j < tamanho; j++) // corre colunas de acordo c o tamanho
            matriz[i][j] = 'A' + rand() % 26; // coloca uma letra aleatoria entre 'A' e 'Z', como rand so retorna max rand, p criar aleatoriedade em letras se cria vetor com 26 char e empurra pra 'A'
}                                             // o "%26" é o limitador pra somente gerar aleator dentro do intervalo do resto da divisao por 26 (entre 0 e 25)

void mostrarMatriz(char matriz[MAX][MAX], int tamanho) {
    printf("   "); // espaco p ficar bonito ne
    for (int j = 0; j < tamanho; j++)
        printf("%2d ", j + 1); //imprime o índice das colunas (1 2 3...), no print usa o "j+1" pra comecar a contar do 1, nao do 0
    printf("\n");

    for (int i = 0; i < tamanho; i++) {
        printf("%2d ", i + 1); // agr imprime o das linhas, mesma logica
        for (int j = 0; j < tamanho; j++)
            printf(" %c ", matriz[i][j]); // imprime o caractere de [i][j], vulgo das linhas e colunas da matriz/ do tabuleiro
        printf("\n"); // quebra de linha ao final de cada linha p ficar bonito
    }
}

/*essa função vai inicializar o arquivo replay.txt como write, já que ele irá iniciar 
pela primeira vez no código, e escrever a dificuldade, tamanho e quantidade de 
palavras escolhidas pelo jogador. Posteriormente irá fornecer as informações 
contidas na struct palavras para cada palavra no jogo*/
void fileiniciarreplay(Dificuldade modo, int tamanho, Palavra palavras[]) {
    FILE *arq = fopen("replay.txt", "w");
    if (!arq){ 
        printf("ih! erro ao registrar o inicio do replay...\n");
        return;
    }

    fprintf(arq, "DIFICULDADE: %d\n", modo);
    fprintf(arq, "TAMANHO: %d\n", tamanho);

    if (modo == FACIL) {
        fprintf(arq, "QTD_PALAVRAS: 3\n");
    }
    else if (modo == MEDIO) {
        fprintf(arq, "QTD_PALAVRAS: 5\n");
    }
    else if (modo == DIFICIL) {
        fprintf(arq, "QTD_PALAVRAS: 7\n");
    }

    if (modo == FACIL) {
        fprintf(arq, "PALAVRAS:\n");
        for (int i = 0; i < 3; i++){
            fprintf(arq, " %s\n", palavras[i].texto);
        }
    }
    else if (modo == MEDIO) {
        fprintf(arq, "PALAVRAS:\n");
        for (int i = 0; i < 5; i++){
            fprintf(arq, " %s\n", palavras[i].texto);
        }
    }
    else if (modo == DIFICIL) {
        fprintf(arq, "PALAVRAS:\n");
        for (int i = 0; i < 7; i++){
            fprintf(arq, " %s\n", palavras[i].texto);
        }
    }

    fprintf(arq, "\nJOGADAS:\n");
    fclose(arq);
}

/*essa função vai inicializar o arquivo replay.txt como append para não sobescrever 
as informações já contidas e apenas adicionar e irá informar no arquivo cada tentativa 
escrita pelo jogador.*/


/*essa função executa o replay no modo r apenas para ler*/
void fileexecutareplay() {
    FILE *arq = fopen("replay.txt", "r");
    if (!arq) {
        printf("ops, não consegui abrir o arquivo para a leitura do replay...");
        return;
    }

    char linha[100];

    printf("\n===| RESUMO DA PARTIDA |===\n\n");

    // Imprime o resumo detalhado da partida ('replay.txt')
    while (fgets(linha, sizeof(linha), arq)) {
        // ... (Seu código existente para ler e imprimir DIFICULDADE, TAMANHO, QTD_PALAVRAS, etc.)
        if (strncmp(linha, "DIFICULDADE:", 12) == 0) {
            int d;
            sscanf(linha, "DIFICULDADE: %d", &d);
            printf("MODO: %s\n",
                   d == 1 ? "FACIL" : (d == 2 ? "MEDIO" : "DIFICIL"));
        }
        else if (strncmp(linha, "TAMANHO:", 8) == 0) { 
            int t;
            sscanf(linha, "TAMANHO: %d", &t);
            printf("TAMANHO DO TABULEIRO: %dx%d\n", t, t);
        }
        else if (strncmp(linha, "QTD_PALAVRAS:", 13) == 0) {
            int q;
            sscanf(linha, "QTD_PALAVRAS: %d", &q);
            printf("QUANTIDADE DE PALAVRAS: %d\n", q);
        }
        else if (strncmp(linha, "PALAVRAS:", 9) == 0) { 
            printf("\nPALAVRAS ESCONDIDAS NO JOGO:\n");
        }
        else if (strncmp(linha, "JOGADAS:", 8) == 0) { 
            printf("\nJOGADAS REALIZADAS:\n");
        }
        else if (strncmp(linha, "FIM", 3) == 0) {
            printf("\nFIM DO RESUMO.\n");
        }
        else {
            printf("• %s", linha);
        }
    }

    fclose(arq);
    printf(TEXTO_NEGRITO COR_MAGENTA "\n\n===| HISTÓRICO DE SCORES ACUMULADOS |===\n" COR_RESET);

    FILE *score_log = fopen("score_log.txt", "r");
    if (!score_log) {
        printf("Nenhum score anterior encontrado.\n");
        return;
    }
    
    // Variáveis para leitura do log: partida,score_partida,score_total
    int n_partida, score_partida, score_total;

    while (fscanf(score_log, "%d,%d,%d", &n_partida, &score_partida, &score_total) == 3) {
        printf(COR_AZUL "== Partida %d == " COR_RESET "Score: %d\n", n_partida, score_partida);
    }
    
    // Imprime a pontuação total (a última lida é a mais atual)
    printf(TEXTO_NEGRITO COR_AMARELA "\nSCORE TOTAL GERAL: %d\n" COR_RESET, score_total);

    fclose(score_log);
}

void carregarPalavras(Palavra palavras[], int *qtd) { // le strutura de palavras do arqv
    FILE *arq = fopen("palavras.txt", "r"); // abre o arquivo palavras.txt p leitura, r - read mode, ou seja vai ler oq ta dentro de palavras
    if (!arq) { //se nao conseguir abrir encerra o jogo c erro
        printf("ih, erro ao abrir arquivo 'palavras.txt'...\n");
        exit(1); // erro mas encerra msm com erro
    }

    char temp[MAX_LEN];
    while (fscanf(arq, "%s", temp) != EOF) {
        int len = strlen(temp);

        for (int i = 0; temp[i] != '\0'; i++) {
            if (!isalpha(temp[i])) {
                printf("ih: '%s' contem simbolos ou numeros. somente letras sao permitidas no tabuleiro.\n", temp);
                printf("lembrando que o jogo aceita apenas letras. arrume o arquivo de texto.\n");
                fclose(arq);
                exit(1);
            }
        }

        if (len > tamanhoMatriz) {
            printf("\n ATENCAO: a palavra '%s' (com %d letras) eh muito grande para o modo atual escolhido (%dx%d).\n",
                   temp, len, tamanhoMatriz, tamanhoMatriz);
            printf("por ora, ela sera ignorada. ajuste o arquivo 'palavras.txt' se quiser inclui-la no jogo.\n\n");
            continue;
        }

        if (*qtd >= MAX_PALAVRAS) {
            printf("IH: o arquivo tem mais de %d palavras!\n", MAX_PALAVRAS);
            printf("apague as palavras extras do arquivo de texto.\n");
            fclose(arq);
            exit(1);
        }

        strcpy(palavras[*qtd].texto, temp);
        for (int i = 0; palavras[*qtd].texto[i]; i++)
            palavras[*qtd].texto[i] = toupper(palavras[*qtd].texto[i]);

        palavras[*qtd].encontrada = 0;
        palavras[*qtd].linha = -1;
        palavras[*qtd].coluna = -1;
        palavras[*qtd].dicaUsada = 0; // ✅ CORREÇÃO: inicializa a dica

        (*qtd)++;
    }

    fclose(arq);
}

void inserirPalavrasNaMatriz(char matriz[MAX][MAX], int ocupado[MAX][MAX], Palavra palavras[],int qtd,int tamanho) {
    for (int p = 0; p < qtd; p++) {
        int linha, col, valido = 0;
        int len = strlen(palavras[p].texto);
        Direcao direcao;

        while (!valido) {
            direcao = rand() % 3;
            linha = rand() % tamanho;
            col = rand() % tamanho;
            valido = 1;

            // limites
            if (direcao == HORIZONTAL && col + len > tamanho) valido = 0;
            if (direcao == VERTICAL && linha + len > tamanho) valido = 0;
            if (direcao == DIAGONAL && (linha + len > tamanho || col + len > tamanho)) valido = 0;

            // sobreposição
            if (valido) {
                for (int i = 0; i < len; i++) {
                    int l = linha;
                    int c = col;

                    if (direcao == HORIZONTAL) c += i;
                    else if (direcao == VERTICAL) l += i;
                    else { l += i; c += i; }

                    if (ocupado[l][c]) {
                        valido = 0;
                        break;
                    }
                }
            }
        }

        // insere a palavra
        for (int i = 0; i < len; i++) {
            int l = linha;
            int c = col;

            if (direcao == HORIZONTAL) c += i;
            else if (direcao == VERTICAL) l += i;
            else { l += i; c += i; }

            matriz[l][c] = palavras[p].texto[i];
            ocupado[l][c] = 1;  // MARCA COMO OCUPADO
        }

        palavras[p].linha = linha;
        palavras[p].coluna = col;
        palavras[p].direcao = direcao;
    }
}


int buscarPalavra(Palavra palavras[], int qtd, char busca[MAX_LEN], int linhaDigitada) {
    for (int i = 0; i < qtd; i++) {
        if (strcmp(busca, palavras[i].texto) == 0) {

            if (palavras[i].linha + 1 != linhaDigitada) {
                printf(COR_AMARELA "\npalavra correta, mas linha incorreta!\n" COR_RESET);
                return -1;
            }

            if (palavras[i].encontrada) {
                printf("\nessa palavra ja foi encontrada. tente novamente!\n");
                return -2;
            }

            palavras[i].encontrada = 1;
            printf(COR_VERDE "\nACERTOUUUU! palavra e linha corretas!!!\n" COR_RESET);
            printf(COR_AZUL"\n***OBS: na matriz onde a sua palavra foi encontrada agora havera asteriscos!\n\n\n"COR_RESET);
            return i;   // indice da palavra encontrada
        }
    }
    return -1;
}

void mostrarCoordenadas(Palavra palavras[], int qtd) { // MOSTRAR AS COORD
    printf("\n\n essas foram as palavras escondidas:\n");
    for (int i = 0; i < qtd; i++) {
        printf("• %s (linha %d, coluna %d)\n", palavras[i].texto,
               palavras[i].linha + 1, palavras[i].coluna + 1);
    }
} 

void salvarResultado(Palavra palavras[], int qtd) {
    FILE *arq = fopen("resultado.txt", "a"); ////w- write mode, gera um novo resultado toda vez que ele termina, apaga o arqv anterior e cria um novo com o resultado da partida
    if (!arq) {
        printf("IH! erro ao salvar resultado.\n");
        return;
    }
    fprintf(arq, "\n=-= resultado do Jogo =-=\n\n");
    for (int i = 0; i < qtd; i++) {
        fprintf(arq, "%s - %s (linha %d, coluna %d)\n", palavras[i].texto,
                palavras[i].encontrada ? "ENCONTRADA" : "NÃO ENCONTRADA", // printa se foi encontrada ou nao, 0 ou 1, estilo if else
                palavras[i].linha + 1, palavras[i].coluna + 1);
    }
    fclose(arq);
}

void substituirPorAsteriscos(char matriz[MAX][MAX], Palavra *p) {
    int len = strlen(p->texto);

    for (int i = 0; i < len; i++) {
        if (p->direcao == HORIZONTAL) {
            matriz[p->linha][p->coluna + i] = '*';
        }
        else if (p->direcao == VERTICAL) {
            matriz[p->linha + i][p->coluna] = '*';
        }
        else if (p->direcao == DIAGONAL) {
            matriz[p->linha + i][p->coluna + i] = '*';
        }
    }
}

void darDica(Palavra palavras[], int qtd) {
    int disponiveis[10], cont = 0;

    // cria uma lista com os indices das palavras ainda nao encontradas
    for (int i = 0; i < qtd; i++) {
        if (!palavras[i].encontrada && !palavras[i].dicaUsada) {
            disponiveis[cont++] = i;
        }
    }

    if (cont == 0) {
        printf("\nnenhuma dica disponivel! todas as palavras ja foram encontradas ou ja tiveram dica usada.\n");
        return;
    }

    int indice = rand() % cont;
    Palavra *p = &palavras[disponiveis[indice]];
    p->dicaUsada = 1;

    printf(COR_AZUL"\nDICA: a palavra %d comeca com '%c' e esta na linha %d.\n" COR_RESET,
           indice + 1, p->texto[0], p->linha + 1);
}

void filejogadasreplay(char tentativa[], ResultadoJogada resultado) {
    FILE *arq = fopen("replay.txt", "a");
    if (!arq) return;

    fprintf(arq, "%s %s\n", tentativa, filestatusjogada(resultado));
    fclose(arq);
}

const char* filestatusjogada(ResultadoJogada r) {
    if (r == ACERTO) return "acerto";
    if (r == ERRO) return "erro";
    return "repetida";
}

// Dentro de jogo.c

// ... (após const char* filestatusjogada(ResultadoJogada r))

// Função para ler o score total, adicionar a pontuação da partida e salvar
// Função para ler o score total, adicionar a pontuação da partida e salvar
void salvarScoreAcumulado(Dificuldade modo) {
    int pontos_partida = 0;
    
    // Define a pontuação baseada na dificuldade
    if (modo == FACIL) {
        pontos_partida = 1;
    } else if (modo == MEDIO) {
        pontos_partida = 2;
    } else if (modo == DIFICIL) {
        pontos_partida = 3;
    }
    
    // --- 1. Lógica do Score Total Acumulado ---
    int score_atual = 0;
    
    // Leitura do score total existente
    FILE *arq_leitura = fopen("score_total.txt", "r");
    if (arq_leitura) {
        // Se o arquivo existe e contém um número, lê o score_atual
        fscanf(arq_leitura, "%d", &score_atual);
        fclose(arq_leitura);
    }
    
    int novo_score = score_atual + pontos_partida;
    
    // Escreve o novo score total
    FILE *arq_escrita = fopen("score_total.txt", "w"); // Sobrescreve com o novo total
    if (!arq_escrita) {
        printf("Aviso: Nao foi possivel salvar o score total em 'score_total.txt'.\n");
        return;
    }
    fprintf(arq_escrita, "%d", novo_score);
    fclose(arq_escrita);


    // --- 2. Lógica do Log de Partidas (Novo requisito) ---
    // Abre o log de scores no modo append ('a') para adicionar a pontuação desta partida.
    FILE *log_score = fopen("score_log.txt", "a+"); // 'a+' permite leitura/escrita no final
    if (!log_score) {
        printf("Aviso: Nao foi possivel registrar o score da partida em 'score_log.txt'.\n");
    } else {
        // Primeiro, contamos quantas linhas já existem para determinar o número da partida
        int linha_count = 0;
        char c;
        rewind(log_score); // Volta para o início do arquivo para contar
        while ((c = fgetc(log_score)) != EOF) {
            if (c == '\n') {
                linha_count++;
            }
        }
        partidas_jogadas = linha_count + 1; // A nova partida é a próxima linha

        // Formato: <número_partida>,<pontos_partida>,<pontuacao_total>
        fprintf(log_score, "%d,%d,%d\n", partidas_jogadas, pontos_partida, novo_score);
        fclose(log_score);
    }

    printf(COR_AMARELA "\nSCORE: Voce ganhou %d ponto(s)! Score Total Acumulado: %d.\n" COR_RESET, 
           pontos_partida, novo_score);
}

